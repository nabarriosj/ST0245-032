#Este metodo se encargara de cargar los datos de los archivos csv utilizando pandas
#Sacado de https://riptutorial.com/es/pandas 
import pandas as pd

def carga_datos(entrenamiento, test):
    datos_entrenamiento = []
    datos_test = []
    Filas = []
    #Cargamos el archivo 
    archivo_entrenamiento = open(entrenamiento, encoding='utf-8')
    archivo_test = open(test, encoding='utf-8')

    #Creamos una lista de listas para alojar a los estudiantes 
    for linea in archivo_entrenamiento:
        linea = linea[:-1] #Eliminamos los saltos de lista
        Filas = linea.split(";") #Definimos el caracter de separación
        datos_entrenamiento.append(Filas) 

    #Retiraramos la "cabecera" de los archivos del csv  
    categorias = datos_entrenamiento[0] 

    Filas = []

    for linea in archivo_test:
        linea = linea[:-1] #Eliminamos los saltos de linea
        estudiante = linea.split(";") #Definimos el caracter de separacion 
        datos_test.append(estudiante)
    
    datos_entrenamiento.pop(0) #Eliminamos las "cabeceras" del data set
    datos_test.pop(0) #Eliminamos las "cabeceras" del data set



    #Eliminamos columnas innecesarias, Tomado de https://github.com/luis19fer97/ST0245-032/tree/master/proyecto/codigo
    a = ['estu_consecutivo.1',
    'periodo',
    'fami_numlibros',
    'estu_inst_cod_departamento',
    'estu_tipodocumento.1',
    'estu_nacionalidad.1',
    'estu_genero.1',
    'estu_fechanacimiento.1',
    'periodo.1',
    'estu_estudiante.1',
    'estu_pais_reside.1',
    'estu_cod_reside_depto.1',
    'estu_cod_reside_mcpio.1',
    'fami_ocupacionpadre.1',
    'fami_ocupacionmadre.1',
    'fami_tienedvd',
    'cole_codigo_icfes',
    'cole_nombre_establecimiento',
    'cole_sede_principal',
    'cole_cod_dane_establecimiento',
    'estu_trabajaactualmente',
    'cole_cod_dane_sede',
    'cole_cod_mcpio_ubicacion',
    'cole_cod_depto_ubicacion',
    'desemp_ingles']

    datos_entrenamiento_df = pd.DataFrame.from_records(datos_entrenamiento,columns = categorias)
    datos_test_df = pd.DataFrame.from_records(datos_test,columns = categorias)

    for i in range(len(a)):
        del datos_entrenamiento_df[a[i]]
        del datos_test_df[a[i]]
        categorias.remove(a[i])

    datos_entrenamiento = datos_entrenamiento_df.values.tolist()
    datos_test = datos_test_df.values.tolist()

    return datos_entrenamiento,datos_test,categorias

