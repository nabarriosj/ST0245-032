#Definimos un metodo que crea un nodo con una pregunta asociada, este nodo hace una pregunta, contiene referencia y a los hijos

class nodos:
    def __init__(self, pregunta, rama_verdadera, rama_falsa):  #definimos un constructor para cada crear los nodos 
        self.pregunta = pregunta              
        self.rama_verdadera = rama_verdadera
        self.rama_falsa = rama_falsa