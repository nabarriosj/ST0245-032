from Gini import gini

#Definimos un metodo que nos permia calcular la ganancia de informacion en base a su definicion 

def gain(izq, der, incertidumbre):

    p = float(len(izq)) / (len(izq) + len(der))
    return incertidumbre - p * gini(izq) - (1 - p) * gini(der)

