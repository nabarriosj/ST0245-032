#Definimos un metodo para insertar 
def Insertar(datos_arreglo,cabeceras,Estudiante=None,ID_estudiante=None,atributo=None,nuevo_valor=None):

  if Estudiante == None and ID_estudiante == None and atributo == None and nuevo_valor == None: #Creamos condicion por si no se agregan datos al invocar
    return (print("Error, no fueron introducidos argumentos"))
  if (Estudiante == None and ID_estudiante == None) or  (Estudiante == None and atributo == None) or (Estudiante == None and nuevo_valor == None): #Y creamos uno para cuando faltan algunos datos
    return(print("Error, falta introducir argumentos"))
  
  if Estudiante != None:       #Creamos condicion para cuando el dato Estudiante es diferente de "None"
    datos_arreglo.append(Estudiante)    #Arreglamos el Estudiante a datos_arreglo
  else:   
    if isinstance(ID_estudiante, str) :  #Utilizamos isinstance para comprobar que ID_estudiante es del tipo str 
      for i in range(len(datos_arreglo)):            #Creamos ciclos para recorrer datos_arreglo
        if (datos_arreglo[i][0]) == ID_estudiante:
          ID_estudiante = i
      for j in range(len(cabeceras)):
        if cabeceras[j] == atributo:
          atributo = j  
      datos_arreglo[ID_estudiante][atributo] = nuevo_valor      