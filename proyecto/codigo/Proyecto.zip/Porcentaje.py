from Clasificar import clasificar

#Definimos un metodo donde almacenamos los valores de los datos de pruebra y luego los comparamos con los resultantes para obtener un porcentaje de acierto.

def porcentaje(data_array_test, arbol):
    valores_originales = []
    valores_arrojados = []
    
    
    for row in data_array_test:
        valores_originales.append(row[-1])
        valores_arrojados.append([*clasificar(row, arbol).keys()])

    total = 0

    for i in range(len(valores_originales)):
        if int(valores_originales[i]) == int(valores_arrojados[i][0]):
            total += 1
    
    return (print('Exactitud: ' +str((total/len(valores_originales))*100) +'%'))