from Conteo import conteo
#Definimos un metodo para conocer la cantidad de filas que terminan en una hoja

class hoja:
    def __init__(self, filas):
        self.prediccion = conteo(filas)