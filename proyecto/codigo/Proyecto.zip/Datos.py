#Definimos un metodo que nos permita saber el tipo de dato dentro de las columnas

def num(valor):
    aux = False
    
    if isinstance(valor, int):  #Utilizamos de nuevo el isinstance para saber si es un valor entero
        aux = True  
        return aux 

    #Necesitamos saber si es un float ya que al convertirlo este generara errores 

    try:
        valor = float(valor)
        if isinstance(valor, float) :
            aux = True
            return aux
    except:
           aux = False
           return aux
           #si es un string retorna falso