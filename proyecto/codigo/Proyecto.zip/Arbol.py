from Hoja import hoja
from Nodos import nodos
from Division import division
from Mejor_division import mejor_division

#Definimos un metodo que creara el arbol utilizando recursion partimos del det de datos, calculamos la ganancia y se elige aquella con mayor ganancia

def construir_arbol(filas,cabeceras):

    gain, pregunta = mejor_division(filas,cabeceras)

        if gain == 0:          # si no tenemos ganancia no hay necesidad de partir mas el arbol 
        return hoja(filas)

    filas_verdaderas, filas_falsas = division(filas, pregunta) #En este llamado podemos obtener caracteristica importante para la división del set de datos

    rama_verdadera = construir_arbol(filas_verdaderas,cabeceras) #Llamada recursiva para construir las ramas verdaderas (derechas) del arbol

    rama_falsa = construir_arbol(filas_falsas,cabeceras) #Llamada recursiva para construir las ramas falsa (izquierdas) del arbol

    return nodo_decision(pregunta, rama_verdadera, rama_falsa) #Retornamos un nodo que contiene la mejor pregunta caracteristica y valor para el punto 
