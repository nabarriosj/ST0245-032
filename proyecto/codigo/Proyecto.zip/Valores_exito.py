#Definimos un metodo para obtener los valores de la columna que nos interesa que en es caso es la condicion de exito

def valores_exito(filas, columnas):
    return set([row[columnas] for row in filas])

