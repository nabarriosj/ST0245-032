#Definimos un metodo de borrado que permita eliminar todo el "vector" o un atributo de un estudiante en base a su ID.  
def Borrar (datos_arreglo, categorias, ID_estudiante, atributo=None):

  if isinstance(ID_estudiante, str) :            #Utilizamos isinstance para ver si la variable es de el tipo especifico en este caso str
    for i in range(len(datos_arreglo)):
      if (datos_arreglo[i][0]) == ID_estudiante:
        ID_estudiante = i

  if atributo == None:
    datos_arreglo.pop(ID_estudiante)
  else:
    for j in range(len(categorias)):
      if categorias[j] == atributo:
        atributo = j  
    datos_arreglo[ID_estudiante][atributo] = None
    