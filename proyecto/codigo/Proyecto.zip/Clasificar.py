from Hoja import hoja

#Definimos un metodo para clasificar los individuos en las ramas verdaderas o falsas dependiendo de su resultado en las preguntas

def clasificar(filas, nodo):

    if isinstance(nodo, hoja):    #usamos el isinstance para comprobar si el nodo es del tipo hoja
        return nodo.prediccion

    if nodo.pregunta.match(filas):
        return clasificar(filas, nodo.rama_verdadera)
    else:
        return clasificar(filas, nodo.rama_falsa)
