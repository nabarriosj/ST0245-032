#Definimos un metodo para acceder a los datos de un estudiante
def Acceder(datos_arreglo,val_estudiante,val_dato = None):
  if val_estudiante == None:
    return datos_arreglo[val_estudiante]
  else:
    return datos_arreglo[val_estudiante][val_dato] 