from Datos import num

class pregunta:
    #Utilizamos esta clase para generar las preguntas necesarias para poder subdividir el set de datos, se basan en la ganancia 
    #que es la que nos dice que variables importan o no guardamos una columna con valores y un item para realizar la pregunta, 
    #establecemos para los datos numericos ">=" y para los strings "==" 

    def __init__(self, columna, valor, categorias):
        self.columna = columna                 #utilizada para guardar valores
        self.valor = valor
        self.categorias = categorias

    def match(self, a):
        val = a[self.columna]
        if num(val):
            if self.valor == '':
                return float(val) >= 0
            return float(val) >= float(self.valor)      #pregunta para datos numericos
        else:
            return val == self.valor

    def __repr__(self):
        condicion = "=="
        if num(self.valor):
            condicion = ">="
        return "Is %s %s %s?" % (
            self.categorias[self.columna], condicion, str(self.valor))
