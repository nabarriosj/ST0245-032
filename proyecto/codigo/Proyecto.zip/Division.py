#Definimos un metodo que permita separar el set de datos en aquellos que cumplen y aquellos que no cumplen la pregunta 

def division(filas, pregunta):

    casos_verdaderos, casos_falsos = [], [] 
    for row in filas:
        if pregunta.match(row):     #Creamos una condicion para separar aquellos que cumplen y aquellos que no 
            casos_verdaderos.append(row)
        else:
            casos_falsos.append(row)
    return casos_verdaderos, casos_falsos
