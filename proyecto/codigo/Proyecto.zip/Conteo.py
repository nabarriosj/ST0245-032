#Definimos un metodo que mida la cantidad de valores iguales en una columna del archivo csv

def conteo (filas):
    conteo = {}  #Definimos un diccionario para contar la cantidad de 1 y 0 de la columna exito y asi saber cuantos cumplen y cuantos no
    for fila in filas:
        
        exito = fila[-1] #Debemos acceder a la ultima columna ya que alli se almacena el valor de verdad 
        if exito not in conteo:
            conteo[exito] = 0
        conteo[exito] += 1
    return conteo