from Gini import gini
from Preguntas import pregunta
from Division import division
from Gain import gain

#Definimos un metodo que encuentre la mejor pregunta para "partir" la informacion basandonos en las caracteristicas y el calculo de la ganancia.

def mejor_division(filas,categorias):

    mejor_ganancia = 0  
    mejor_pregunta = None  
    incertidumbre = gini(filas)
    caracteristicas = len(filas[0]) - 1  

    for col in range(caracteristicas):  

        valores = set([fila[col] for fila in filas])  

        for val in valores:  

            p1 = pregunta(col, val, categorias)

            
            filas_verdaderas, filas_falsas = division(filas, p1)

            
            
            if len(filas_verdaderas) == 0 or len(filas_falsas) == 0:
                continue

            
            ganancia = gain(filas_verdaderas, filas_falsas, incertidumbre)

            if ganancia >= mejor_ganancia:
                mejor_ganancia, mejor_pregunta = ganancia, p1

    return mejor_ganancia, mejor_pregunta
