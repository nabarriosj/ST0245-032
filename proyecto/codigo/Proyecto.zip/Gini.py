from Conteo import conteo
#Definimos un metodo que nos permita calcular la impureza de gini 
#La impureza de Gini es una medida de cuán a menudo un elemento elegido aleatoriamente del conjunto sería etiquetado incorrectamente si fue 
#etiquetado de manera aleatoria de acuerdo a la distribución de las etiquetas en el subconjunto, sacado de https://es.wikipedia.org/wiki/Aprendizaje_basado_en_%C3%A1rboles_de_decisi%C3%B3n#Impureza_de_Gini

def gini(filas):  #declaracion inspirada en su definicion 

    conteos = conteo(filas)
    impureza = 1
    for lbl in conteos:
        prueba = conteos[lbl] / float(len(filas))
        impureza -= prueba**2
    return impureza